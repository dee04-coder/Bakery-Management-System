﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class CustomerLogin : Form
    {
        // MySQL connection string
        string connsString = "server=localhost;user id=root;password=Ngom@1229;database=new_schema;";

        public CustomerLogin()
        {
            InitializeComponent();
        }
        private string HashPassword(string password)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                StringBuilder builder = new StringBuilder();
                foreach (byte b in bytes)
                    builder.Append(b.ToString("x2"));
                return builder.ToString();
            }
        }
        private bool AuthenticateCustomer(string email, string password)
        {
            string query = "SELECT COUNT(*) FROM Customer WHERE Email=@mail AND Password=@pass";

            try
            {
                using (MySqlConnection con = new MySqlConnection(connsString))
                {
                    con.Open();
                    using (MySqlCommand cmd = new MySqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@mail", email);
                        cmd.Parameters.AddWithValue("@pass", password); // plain text

                        int count = Convert.ToInt32(cmd.ExecuteScalar());
                        return count > 0; // True if email + password match
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Database error: " + ex.Message, "Error");
                return false;
            }
        }



        private void CustomerLogin_Load(object sender, EventArgs e)
        {

        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string email = txtEmail.Text.Trim();
            string password = txtPassword.Text.Trim();

            if (string.IsNullOrWhiteSpace(email) || string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("Please enter both email and password.", "Error");
                return;
            }

            if (AuthenticateCustomer(email, password))
            {
                MessageBox.Show("✅ Login successful! Welcome.");

                // Open CustomerOrderForm and pass the logged-in customer's email
                Order_Products orderForm = new Order_Products(email);
                orderForm.Show();
                // Hide the login form
                this.Hide();
            }
            else
            {
                MessageBox.Show("❌ Access denied. Invalid email or password.", "Login Failed");
            }
        }
    }
}
