﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Product_Management : Form
    {
        string connsString = "server=localhost;user id=root;password=Ngom@1229;database=new_schema;";

        public Product_Management()
        {
            InitializeComponent();
        }

        private void Product_Management_Load(object sender, EventArgs e)
        {
            LoadSuppliers();
            LoadProducts();
        }
        private void LoadSuppliers()
        {
            try
            {
                using (MySqlConnection con = new MySqlConnection(connsString))
                {
                    con.Open();
                    string query = "SELECT Supplier_ID, Supplier_Name FROM Supplier";
                    using (MySqlCommand cmd = new MySqlCommand(query, con))
                    {
                        using (MySqlDataReader reader = cmd.ExecuteReader())
                        {
                            cmbSupplier.Items.Clear();
                            while (reader.Read())
                            {
                                cmbSupplier.Items.Add(new { ID = reader["Supplier_ID"], Name = reader["Supplier_Name"] });
                            }
                            cmbSupplier.DisplayMember = "Name";
                            cmbSupplier.ValueMember = "ID";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading suppliers: " + ex.Message);
            }
        }

        private void LoadProducts()
        {
            try
            {
                using (MySqlConnection con = new MySqlConnection(connsString))
                {
                    con.Open();
                    string query = "SELECT Product_ID, Name, Description, Price, Quantity, Supplier_ID FROM products";
                    MySqlDataAdapter da = new MySqlDataAdapter(query, con);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dgvProducts.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading products: " + ex.Message);
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtProductName.Text) || string.IsNullOrWhiteSpace(txtPrice.Text)
        || string.IsNullOrWhiteSpace(txtQuantity.Text) || cmbSupplier.SelectedIndex == -1)
            {
                MessageBox.Show("Please fill all fields.");
                return;
            }

            try
            {
                using (MySqlConnection con = new MySqlConnection(connsString))
                {
                    con.Open();
                    string query = "INSERT INTO products (Name, Description, Price, Quantity, Supplier_ID) " +
                                   "VALUES (@name, @desc, @price, @qty, @supplier)";

                    using (MySqlCommand cmd = new MySqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@name", txtProductName.Text.Trim());
                        cmd.Parameters.AddWithValue("@desc", txtDescription.Text.Trim());
                        cmd.Parameters.AddWithValue("@price", Convert.ToDecimal(txtPrice.Text.Trim()));
                        cmd.Parameters.AddWithValue("@qty", Convert.ToInt32(txtQuantity.Text.Trim()));
                        cmd.Parameters.AddWithValue("@supplier", ((dynamic)cmbSupplier.SelectedItem).ID);

                        cmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Product added successfully!");
                LoadProducts(); // <-- Auto-refresh
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error adding product: " + ex.Message);
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (dgvProducts.SelectedRows.Count == 0)
            {
                MessageBox.Show("Select a product to update.");
                return;
            }

            int productId = Convert.ToInt32(dgvProducts.SelectedRows[0].Cells["Product_ID"].Value);

            try
            {
                using (MySqlConnection con = new MySqlConnection(connsString))
                {
                    con.Open();
                    string query = "UPDATE products SET Name=@name, Description=@desc, Price=@price, " +
                                   "Quantity=@qty, Supplier_ID=@supplier WHERE Product_ID=@id";

                    using (MySqlCommand cmd = new MySqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@name", txtProductName.Text.Trim());
                        cmd.Parameters.AddWithValue("@desc", txtDescription.Text.Trim());
                        cmd.Parameters.AddWithValue("@price", Convert.ToDecimal(txtPrice.Text.Trim()));
                        cmd.Parameters.AddWithValue("@qty", Convert.ToInt32(txtQuantity.Text.Trim()));
                        cmd.Parameters.AddWithValue("@supplier", ((dynamic)cmbSupplier.SelectedItem).ID);
                        cmd.Parameters.AddWithValue("@id", productId);

                        cmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Product updated successfully!");
                LoadProducts();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error updating product: " + ex.Message);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dgvProducts.SelectedRows.Count == 0)
            {
                MessageBox.Show("Select a product to delete.");
                return;
            }

            int productId = Convert.ToInt32(dgvProducts.SelectedRows[0].Cells["Product_ID"].Value);

            try
            {
                using (MySqlConnection con = new MySqlConnection(connsString))
                {
                    con.Open();
                    string query = "DELETE FROM products WHERE Product_ID=@id";

                    using (MySqlCommand cmd = new MySqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@id", productId);
                        cmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Product deleted successfully!");
                LoadProducts();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error deleting product: " + ex.Message);
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            LoadProducts(); // Call the same method that loads products into the DataGridView
            MessageBox.Show("Product list refreshed!", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
