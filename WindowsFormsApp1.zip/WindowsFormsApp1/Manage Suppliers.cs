﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Manage_Suppliers : Form
    {
        string connsString = "server=localhost;user id=root;password=Ngom@1229;database=new_schema;";
        public Manage_Suppliers()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void Manage_Suppliers_Load(object sender, EventArgs e)
        {
            LoadSuppliers();
        }
        private void LoadSuppliers()
        {
            try
            {
                using (MySqlConnection con = new MySqlConnection(connsString))
                {
                    con.Open();
                    string query = "SELECT Supplier_ID, Supplier_Name, Phone_Number, Email FROM Supplier";
                    MySqlDataAdapter da = new MySqlDataAdapter(query, con);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dgvSuppliers.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading suppliers: " + ex.Message);
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtName.Text) ||
        string.IsNullOrWhiteSpace(txtPhone.Text) ||
        string.IsNullOrWhiteSpace(txtEmail.Text))
            {
                MessageBox.Show("Please fill all fields.");
                return;
            }

            try
            {
                using (MySqlConnection con = new MySqlConnection(connsString))
                {
                    con.Open();
                    string query = "INSERT INTO Supplier (Supplier_Name, Phone_Number, Email) " +
                                   "VALUES (@name, @phone, @email)";
                    using (MySqlCommand cmd = new MySqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@name", txtName.Text.Trim());
                        cmd.Parameters.AddWithValue("@phone", txtPhone.Text.Trim());
                        cmd.Parameters.AddWithValue("@email", txtEmail.Text.Trim());
                        cmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Supplier added successfully!");
                LoadSuppliers(); // Auto-refresh
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error adding supplier: " + ex.Message);
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (dgvSuppliers.SelectedRows.Count == 0)
            {
                MessageBox.Show("Select a supplier to update.");
                return;
            }

            int supplierId = Convert.ToInt32(dgvSuppliers.SelectedRows[0].Cells["Supplier_ID"].Value);

            try
            {
                using (MySqlConnection con = new MySqlConnection(connsString))
                {
                    con.Open();
                    string query = "UPDATE Supplier SET Supplier_Name=@name, Phone_Number=@phone, Email=@email " +
                                   "WHERE Supplier_ID=@id";
                    using (MySqlCommand cmd = new MySqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@name", txtName.Text.Trim());
                        cmd.Parameters.AddWithValue("@phone", txtPhone.Text.Trim());
                        cmd.Parameters.AddWithValue("@email", txtEmail.Text.Trim());
                        cmd.Parameters.AddWithValue("@id", supplierId);
                        cmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Supplier updated successfully!");
                LoadSuppliers(); // Auto-refresh
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error updating supplier: " + ex.Message);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dgvSuppliers.SelectedRows.Count == 0)
            {
                MessageBox.Show("Select a supplier to delete.");
                return;
            }

            int supplierId = Convert.ToInt32(dgvSuppliers.SelectedRows[0].Cells["Supplier_ID"].Value);

            try
            {
                using (MySqlConnection con = new MySqlConnection(connsString))
                {
                    con.Open();
                    string query = "DELETE FROM Supplier WHERE Supplier_ID=@id";
                    using (MySqlCommand cmd = new MySqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@id", supplierId);
                        cmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Supplier deleted successfully!");
                LoadSuppliers(); // Auto-refresh
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error deleting supplier: " + ex.Message);
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            LoadSuppliers(); // Reload data
        }
    }
}
