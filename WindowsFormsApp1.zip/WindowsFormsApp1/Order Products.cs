﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace WindowsFormsApp1
{
    public partial class Order_Products : Form
    {
        string connsString = "server=localhost;user id=root;password=Ngom@1229;database=new_schema;";
        string customerEmail;
        public Order_Products(string email)
        {
            InitializeComponent();
            customerEmail = email;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Order_Products_Load(object sender, EventArgs e)
        {
            LoadProducts();      // existing method to load products in ComboBox
            LoadPreviousOrders();
        }
        private void LoadProducts()
        {
            try
            {
                using (MySqlConnection con = new MySqlConnection(connsString))
                {
                    con.Open();
                    string query = "SELECT Product_ID, Name, Price FROM products";
                    using (MySqlCommand cmd = new MySqlCommand(query, con))
                    {
                        using (MySqlDataReader reader = cmd.ExecuteReader())
                        {
                            DataTable dt = new DataTable();
                            dt.Load(reader);
                            cmbProducts.DataSource = dt;
                            cmbProducts.DisplayMember = "Name";
                            cmbProducts.ValueMember = "Product_ID";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading products: " + ex.Message);
            }
        }

        private void cmbProducts_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbProducts.SelectedIndex != -1)
            {
                DataRowView row = (DataRowView)cmbProducts.SelectedItem;
                lblProductPrice.Text = $"Price: R{row["Price"]}";
                txtPrice.Text = row["Price"].ToString();
            }
        }


        private void btnPlaceOrder_Click(object sender, EventArgs e)
        {
            if (cmbProducts.SelectedIndex == -1 || string.IsNullOrWhiteSpace(txtQuantity.Text) || string.IsNullOrWhiteSpace(txtPrice.Text))
            {
                MessageBox.Show("Please select a product, enter quantity and price.");
                return;
            }

            int productId = Convert.ToInt32(cmbProducts.SelectedValue);
            int quantity = int.Parse(txtQuantity.Text.Trim());
            decimal unitPrice = decimal.Parse(txtPrice.Text.Trim()); // use user-entered price

            try
            {
                using (MySqlConnection con = new MySqlConnection(connsString))
                {
                    con.Open();

                    // Insert into Orders
                    string orderQuery = "INSERT INTO Orders (Customer_ID, Order_Date, Order_Status) " +
                                        "VALUES ((SELECT Customer_ID FROM Customer WHERE Email=@mail), @date, 'Pending')";
                    using (MySqlCommand orderCmd = new MySqlCommand(orderQuery, con))
                    {
                        orderCmd.Parameters.AddWithValue("@mail", customerEmail);
                        orderCmd.Parameters.AddWithValue("@date", DateTime.Now);
                        orderCmd.ExecuteNonQuery();
                    }

                    // Insert into Order_Item
                    string orderItemQuery = "INSERT INTO Order_Item (Order_ID, Product_ID, Quantity, Unit_Price) " +
                                            "VALUES (LAST_INSERT_ID(), @productId, @qty, @unitPrice)";
                    using (MySqlCommand cmd2 = new MySqlCommand(orderItemQuery, con))
                    {
                        cmd2.Parameters.AddWithValue("@productId", productId);
                        cmd2.Parameters.AddWithValue("@qty", quantity);
                        cmd2.Parameters.AddWithValue("@unitPrice", unitPrice);
                        cmd2.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Order placed successfully!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error placing order: " + ex.Message);
            }
        }


        private void btnLogout_Click(object sender, EventArgs e)
        {
            this.Close();
            WelcomPage welcome = new WelcomPage();
            welcome.Show();

        }

        private void LoadPreviousOrders()
        {
            try
            {
                using (MySqlConnection con = new MySqlConnection(connsString))
                {
                    con.Open();

                    // Get the Customer_ID based on email
                    string getCustomerIdQuery = "SELECT Customer_ID FROM Customer WHERE Email=@mail";
                    object result;
                    int customerId;
                    using (MySqlCommand cmd = new MySqlCommand(getCustomerIdQuery, con))
                    {
                        cmd.Parameters.AddWithValue("@mail", customerEmail);
                        result = cmd.ExecuteScalar();
                        if (result == null)
                        {
                            // Customer not found
                            dgvOrders.DataSource = null;
                            return;
                        }
                        customerId = Convert.ToInt32(result);
                    }

                    // Get all previous orders for this customer
                    string query = @"
                SELECT o.Order_ID, o.Order_Date, o.Order_Status, 
                       p.Name AS Product_Name, oi.Quantity, oi.Unit_Price
                FROM Orders o
                INNER JOIN Order_Item oi ON o.Order_ID = oi.Order_ID
                INNER JOIN products p ON oi.Product_ID = p.Product_ID
                WHERE o.Customer_ID = @customerId
                ORDER BY o.Order_Date DESC";

                    using (MySqlCommand cmd = new MySqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@customerId", customerId);

                        using (MySqlDataAdapter da = new MySqlDataAdapter(cmd))
                        {
                            DataTable dt = new DataTable();
                            da.Fill(dt);
                            dgvOrders.DataSource = dt;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading previous orders: " + ex.Message);
            }
        }
    private void UpdatePendingOrdersToComplete()
        {
            try
            {
                using (MySqlConnection con = new MySqlConnection(connsString))
                {
                    con.Open();

                    string query = @"
                UPDATE Orders o
                INNER JOIN Customer c ON o.Customer_ID = c.Customer_ID
                SET o.Order_Status = 'Complete'
                WHERE c.Email = @mail AND o.Order_Status = 'Pending'";

                    using (MySqlCommand cmd = new MySqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@mail", customerEmail);
                        cmd.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error updating orders: " + ex.Message);
            }
        }

    } 
}
