﻿using MySql.Data.MySqlClient;
using Mysqlx.Crud;
using System;
using System.Data;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class FormManagerDashBoard : Form
    {
        // MySQL connection string
        string connsString = "server=localhost;user id=root;password=Ngom@1229;database=new_schema;";

        public FormManagerDashBoard()
        {
            InitializeComponent();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            

        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            
        }
        private void LoadOrders()
        {
            try
            {
                using (MySqlConnection con = new MySqlConnection(connsString))
                {
                    con.Open();
                    string query = @"
                SELECT o.Order_ID, c.F_Name, c.L_Name, o.Order_Date, o.Order_Status
                FROM Orders o
                INNER JOIN Customer c ON o.Customer_ID = c.Customer_ID
                ORDER BY o.Order_Date DESC";

                    MySqlDataAdapter da = new MySqlDataAdapter(query, con);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dgvOrders.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading orders: " + ex.Message);
            }
        }

        private void FormManagerDashBoard_Load(object sender, EventArgs e)
        {
            LoadOrders();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (dgvOrders.SelectedRows.Count == 0)
            {
                MessageBox.Show("Select an order to update.");
                return;
            }

            int orderId = Convert.ToInt32(dgvOrders.SelectedRows[0].Cells["Order_ID"].Value);
            string newStatus = cmbStatus.SelectedItem?.ToString();

            if (string.IsNullOrWhiteSpace(newStatus))
            {
                MessageBox.Show("Select a status to update.");
                return;
            }

            try
            {
                using (MySqlConnection con = new MySqlConnection(connsString))
                {
                    con.Open();
                    string query = "UPDATE Orders SET Order_Status=@status WHERE Order_ID=@id";

                    using (MySqlCommand cmd = new MySqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@status", newStatus);
                        cmd.Parameters.AddWithValue("@id", orderId);
                        cmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Order status updated successfully!");
                LoadOrders(); // Auto-refresh
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error updating order status: " + ex.Message);
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            LoadOrders();
        }

       
        private void dgvOrders_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvOrders.SelectedRows.Count > 0)
            {
                string firstName = dgvOrders.SelectedRows[0].Cells["FirstName"].Value.ToString();
                string lastName = dgvOrders.SelectedRows[0].Cells["LastName"].Value.ToString();
                lblCustomer.Text = $"Customer: {firstName} {lastName}";
            }
        }

    }
}
