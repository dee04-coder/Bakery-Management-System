﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Manager_Operations : Form
    {
        public Manager_Operations()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Manage_Suppliers suppliers = new Manage_Suppliers(); // make sure ManagerLogin form exists
            suppliers.Show();
            this.Hide(); // Hide the welcome form
        }

        private void btnCustomers_Click(object sender, EventArgs e)
        {
            FormManagerDashBoard orders = new FormManagerDashBoard(); // make sure ManagerLogin form exists
            orders.Show();
            this.Hide(); // Hide the welcome form
        }

        private void btnProducts_Click(object sender, EventArgs e)
        {
            Product_Management products = new Product_Management(); // make sure ManagerLogin form exists
            products.Show();
            this.Hide(); // Hide the welcome form
        }
    }
}
