﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class LoggingIn : Form
    {
        string connsString = "server=localhost;user id=root;password=Ngom@1229;database=new_schema;";
        public LoggingIn()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string email = txtUserName.Text.Trim(); // username field now holds email
            string password = txtPassword.Text.Trim();

            if (string.IsNullOrWhiteSpace(email) || string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("Please enter both email and password.", "Error");
                return;
            }

            try
            {
                using (MySqlConnection con = new MySqlConnection(connsString))
                {
                    con.Open();

                    string query = "SELECT COUNT(*) FROM Admin WHERE Email=@mail AND Password=@password";

                    using (MySqlCommand cmd = new MySqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@mail", email);
                        cmd.Parameters.AddWithValue("@password", password);

                        int count = Convert.ToInt32(cmd.ExecuteScalar());

                        if (count > 0)
                        {
                            MessageBox.Show("✅ Login successful! Welcome.");
                            Manager_Operations operations = new Manager_Operations();
                            this.Hide();
                            operations.ShowDialog();
                            this.Close();
                        }
                        else
                        {
                            MessageBox.Show("❌ Invalid email or password!", "Access Denied",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Database error: " + ex.Message, "Error");
            }
        }

        private void LoggingIn_Load(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
