﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class WelcomPage : Form
    {
        

        public WelcomPage()
        {
            InitializeComponent();
        }

        private void WelcomPage_Load(object sender, EventArgs e)
        {
        }

        private void btnCustomer_Click(object sender, EventArgs e)
        {
            CustomerLogin customerLoginForm = new CustomerLogin();
            customerLoginForm.Show();
            this.Hide(); // Hide the welcome form
        }

        private void btnManager_Click(object sender, EventArgs e)
        {
            LoggingIn managerLoginForm = new LoggingIn(); // make sure ManagerLogin form exists
            managerLoginForm.Show();
            this.Hide(); // Hide the welcome form
        }
    }
}
